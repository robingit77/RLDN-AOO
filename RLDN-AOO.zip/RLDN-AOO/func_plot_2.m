% This function draw the benchmark functions

function func_plot_2(func_name)

x=-100:5:100; y=x; %[-100,100]      

L=length(x);
f=[];
z = zeros(1,98);
for i=1:L
    for j=1:L
          X =[x(i),y(j),z];
          % f(i,j)=fhd([x(i),y(j)]);
          f(i,j)=cec17_func(X', func_name);
   
    end
end

contour(x,y,f)
end

